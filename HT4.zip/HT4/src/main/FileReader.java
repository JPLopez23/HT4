public interface FileReader {
    String readFile(String filePath);
}