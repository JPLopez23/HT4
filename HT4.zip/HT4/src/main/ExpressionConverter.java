public interface ExpressionConverter {
    String toPostfix(String infixExpression);
}